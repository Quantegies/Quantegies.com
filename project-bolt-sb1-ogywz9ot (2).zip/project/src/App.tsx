import React from 'react';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { CodeEditor } from './components/CodeEditor';
import { OrderFlow } from './components/OrderFlow';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navigation />
      <Hero />
      
      <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-[#FF69B4] to-[#1E90FF] bg-clip-text text-transparent">
            Advanced Algorithm Development
          </h2>
          <p className="mt-4 text-xl text-gray-400 max-w-2xl mx-auto">
            Build and backtest your strategies with institutional-grade tools
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold">Strategy Development</h3>
            <p className="text-gray-400">
              Write, test, and deploy your trading algorithms with our advanced editor
            </p>
            <CodeEditor />
          </div>

          <div className="space-y-6">
            <h3 className="text-2xl font-semibold">Market Analysis</h3>
            <p className="text-gray-400">
              Real-time order flow analysis and market depth visualization
            </p>
            <OrderFlow />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            'Live code editing with syntax highlighting',
            'Integrated backtesting engine',
            'Real-time market data access',
            'Advanced visualization tools',
            'One-click deployment to production',
            'Comprehensive strategy analytics'
          ].map((feature, index) => (
            <div
              key={index}
              className="p-6 bg-gradient-to-r from-white/10 to-transparent rounded-lg border border-white/10 hover:border-white/20 transition-colors group"
            >
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 rounded-full bg-gradient-to-r from-[#FF69B4] to-[#1E90FF]" />
                <span className="text-gray-300 group-hover:text-white transition-colors">{feature}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default App;