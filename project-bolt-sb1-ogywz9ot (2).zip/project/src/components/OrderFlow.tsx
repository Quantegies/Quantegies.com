import React from 'react';

export function OrderFlow() {
  return (
    <div className="bg-black/50 rounded-xl p-6 backdrop-blur-sm border border-white/10 shadow-2xl shadow-[#1E90FF]/5">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold">Order Flow Analysis</h3>
        <div className="flex items-center space-x-4">
          <span className="text-sm text-gray-400">SPY</span>
          <span className="text-sm text-[#FFD700]">$428.92</span>
          <span className="text-sm text-[#FF69B4]">-0.32%</span>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="bg-gradient-to-b from-[#FF69B4]/20 to-transparent p-4 rounded-lg">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">Asks</span>
              <span className="text-[#FF69B4]">Volume</span>
            </div>
            {[429.15, 429.10, 429.05, 429.00, 428.95].map((price, i) => (
              <div key={i} className="flex justify-between items-center py-1">
                <span>{price}</span>
                <div className="w-24 bg-[#FF69B4]/20 rounded-full h-2">
                  <div 
                    className="bg-[#FF69B4] h-full rounded-full" 
                    style={{ width: `${Math.random() * 100}%` }} 
                  />
                </div>
              </div>
            ))}
          </div>
          
          <div className="bg-gradient-to-t from-[#1E90FF]/20 to-transparent p-4 rounded-lg">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-400">Bids</span>
              <span className="text-[#1E90FF]">Volume</span>
            </div>
            {[428.90, 428.85, 428.80, 428.75, 428.70].map((price, i) => (
              <div key={i} className="flex justify-between items-center py-1">
                <span>{price}</span>
                <div className="w-24 bg-[#1E90FF]/20 rounded-full h-2">
                  <div 
                    className="bg-[#1E90FF] h-full rounded-full" 
                    style={{ width: `${Math.random() * 100}%` }} 
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-black/30 rounded-lg p-4">
          <h4 className="text-sm font-medium text-gray-400 mb-4">Heat Map</h4>
          <div className="grid grid-cols-10 gap-1">
            {Array.from({ length: 100 }).map((_, i) => (
              <div
                key={i}
                className="aspect-square rounded-sm"
                style={{
                  backgroundColor: `hsl(${Math.random() * 60 + 180}, 100%, ${Math.random() * 30 + 40}%`,
                  opacity: Math.random() * 0.5 + 0.5
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}