import React from 'react';
import { Cpu, LineChart, Lock, Server } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative overflow-hidden bg-black text-white">
      {/* Animated gradient background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-[#FF69B4]/20 via-[#1E90FF]/20 to-[#FFD700]/20 opacity-50 animate-gradient" />
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1642790551116-18e150f248e3?auto=format&fit=crop&q=80')] opacity-10 bg-cover bg-center" />
      </div>
      
      <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <div className="text-center">
          <div className="inline-block">
            <h1 className="text-5xl font-bold tracking-tight bg-gradient-to-r from-[#FF69B4] via-[#1E90FF] to-[#FFD700] bg-clip-text text-transparent animate-text-gradient">
              
            </h1>
            <div className="h-1 bg-gradient-to-r from-[#FF69B4] via-[#1E90FF] to-[#FFD700] rounded-full mt-2" />
          </div>
          <p className="mt-6 text-xl text-gray-300 max-w-2xl mx-auto">
            Build, Deploy, and Optimize Your Trading Algorithms with Advanced AI and Real-time Market Data
          </p>
          
          <div className="mt-10 flex justify-center gap-6">
            <button className="px-8 py-4 bg-gradient-to-r from-[#FF69B4] to-[#1E90FF] rounded-lg font-semibold hover:opacity-90 transition-opacity shadow-lg shadow-[#FF69B4]/20 relative overflow-hidden group">
              <span className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform" />
              <span className="relative">Get Started Free</span>
            </button>
            <button className="px-8 py-4 border-2 border-[#1E90FF] rounded-lg font-semibold hover:bg-[#1E90FF]/10 transition-colors relative overflow-hidden group">
              <span className="absolute inset-0 bg-[#1E90FF]/10 translate-y-full group-hover:translate-y-0 transition-transform" />
              <span className="relative">View Live Demo</span>
            </button>
          </div>
        </div>

        <div className="mt-24 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: <Cpu className="w-10 h-10 text-[#FF69B4]" />,
              title: 'Deep Q Networks Learning',
              description: 'Train and deploy sophisticated AI models for smarter, data-driven strategies'
            },
            {
              icon: <LineChart className="w-10 h-10 text-[#1E90FF]" />,
              title: 'Real-time Analysis',
              description: 'Access tick-by-tick market data with advanced order flow visualization'
            },
            {
              icon: <Server className="w-10 h-10 text-[#FFD700]" />,
              title: 'Private Servers',
              description: 'Deploy on isolated, low-latency environments optimized for HFT'
            },
            {
              icon: <Lock className="w-10 h-10 text-[#FFA500]" />,
              title: 'Secure Integration',
              description: 'Connect safely with your preferred brokers using encrypted channels'
            }
          ].map((feature, index) => (
            <div
              key={index}
              className="relative p-8 bg-gradient-to-br from-white/10 to-transparent rounded-xl border border-white/10 backdrop-blur-sm group hover:border-white/20 transition-colors"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative">
                <div className="p-3 bg-white/5 rounded-lg inline-block">
                  {feature.icon}
                </div>
                <h3 className="mt-6 text-xl font-semibold bg-gradient-to-r from-white to-white/80 bg-clip-text">
                  {feature.title}
                </h3>
                <p className="mt-4 text-gray-400 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}