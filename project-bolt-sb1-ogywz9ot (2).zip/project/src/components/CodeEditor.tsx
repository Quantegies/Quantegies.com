import React from 'react';

const exampleCode = `import numpy as np
import pandas as pd

def HFT_strategy(data):
    # Calculate Order Flow
    data['HFT'] = data['PER TICK'].diff(VOL=69)
    data['Signal'] = np.where(data['HFT'] > 0, 1, -1)
    
    # Add volatility adjustment
    data['Volatility'] = data['Close'].rolling(window=20).std()
    data['Position_Size'] = 1000 / data['Volatility']
    
    return data

# Load and process market data
data = load_market_data('SPY', interval='1 sec')
results = HFT_strategy(data)

# Backtest and visualize
performance = backtest_strategy(results)
visualize_results(performance)
plot_equity_curve(performance)`;

export function CodeEditor() {
  return (
    <div className="bg-black/50 rounded-xl p-6 backdrop-blur-sm border border-white/10 shadow-2xl shadow-[#FF69B4]/5 group hover:border-white/20 transition-all duration-300">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <div className="flex space-x-2">
            <div className="w-3 h-3 rounded-full bg-[#FF69B4]" />
            <div className="w-3 h-3 rounded-full bg-[#FFD700]" />
            <div className="w-3 h-3 rounded-full bg-[#1E90FF]" />
          </div>
          <div className="h-6 w-px bg-white/10" />
          <span className="text-sm font-medium text-gray-400">HFT_strategy.py</span>
        </div>
        <div className="flex items-center space-x-3">
          <span className="text-sm font-medium text-[#1E90FF]">Python</span>
          <div className="h-6 w-px bg-white/10" />
          <button className="text-sm text-gray-400 hover:text-white transition-colors">
            Copy
          </button>
        </div>
      </div>
      <pre className="text-sm text-gray-300 font-mono overflow-x-auto leading-relaxed">
        <code>{exampleCode}</code>
      </pre>
      <div className="mt-6 pt-6 border-t border-white/10">
        <div className="flex items-center justify-between text-sm text-gray-400">
          <div className="flex items-center space-x-4">
            <span>Strategy Type: HFT</span>
            <span>Timeframe: 1 sec</span>
          </div>
          <button className="px-4 py-2 bg-[#1E90FF]/10 text-[#1E90FF] rounded-lg hover:bg-[#1E90FF]/20 transition-colors">
            Run Backtest
          </button>
        </div>
      </div>
    </div>
  );
}