import React from 'react';
import { Mail, MessageCircle, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-black/80 border-t border-white/10 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold bg-gradient-to-r from-[#FF69B4] to-[#1E90FF] bg-clip-text text-transparent">
              Quantegies
            </h3>
            <p className="mt-4 text-gray-400">
              Build, deploy, and train your trading algorithms with institutional-grade tools.
            </p>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center text-gray-400">
                <MapPin size={20} className="mr-2 text-[#FF69B4]" />
                3345 Michelson Dr, Irvine, CA
              </li>
              <li className="flex items-center text-gray-400">
                <Mail size={20} className="mr-2 text-[#1E90FF]" />
                support@quantegies.com
              </li>
              <li className="flex items-center text-gray-400">
                <MessageCircle size={20} className="mr-2 text-[#FFD700]" />
                Join our Discord
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Resources</h4>
            <ul className="space-y-2">
              <li>
                <a href="/docs" className="text-gray-400 hover:text-white transition-colors">
                  Documentation
                </a>
              </li>
              <li>
                <a href="/api" className="text-gray-400 hover:text-white transition-colors">
                  API Reference
                </a>
              </li>
              <li>
                <a href="/blog" className="text-gray-400 hover:text-white transition-colors">
                  Blog
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-4">Legal</h4>
            <ul className="space-y-2">
              <li>
                <a href="/terms" className="text-gray-400 hover:text-white transition-colors">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="/privacy" className="text-gray-400 hover:text-white transition-colors">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="/security" className="text-gray-400 hover:text-white transition-colors">
                  Security
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Quantegies. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}